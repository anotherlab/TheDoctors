﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using TheDoctors.Data;
using TheDoctors.Resources;
using Xamarin.Forms;
using TheDoctors;

namespace TheDoctors.views
{
    public partial class DetailsPage : ContentPage
    {
        public DetailsPage(DoctorActor doctor)
        {
            this.Title = LocalizationResources.DetailsTitle;  // Does not work
            BindingContext = doctor;
            InitializeComponent();
        }
    }
}
